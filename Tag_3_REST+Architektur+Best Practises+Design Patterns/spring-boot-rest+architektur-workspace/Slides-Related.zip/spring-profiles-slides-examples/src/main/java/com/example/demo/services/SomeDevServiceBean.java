package com.example.demo.services;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service(SomeService.NAME)
@Profile("dev")
public class SomeDevServiceBean implements SomeService {
	@Override
	public String hello(String input) {
		return "DEV Service stub: hello " + input;
	}
}