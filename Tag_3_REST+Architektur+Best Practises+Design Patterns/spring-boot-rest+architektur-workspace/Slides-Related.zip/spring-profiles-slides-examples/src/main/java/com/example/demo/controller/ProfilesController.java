package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.config.ProfileManager;
import com.example.demo.services.SomeService;

@RestController
public class ProfilesController {

	@Value("${app.message}")
	private String msg;
	@Autowired
	private String myBean;

	@Autowired
	private ProfileManager profileManager;
	
	@Autowired
	private SomeService someService;
	
	
	
	@GetMapping("/activeprofile")
	public String getActiveProfile() {
		return "Active profile is :: " + msg + " <br/> <br/>Configured bean value is :: " + myBean + " / msg: " + msg;
	}
	
	@GetMapping("/showProfiles")
	ResponseEntity<String> showProfiles() {
		List<String> activeProfiles = profileManager.getActiveProfiles();
		return ResponseEntity.ok(activeProfiles.toString());
	}
	
	
	@GetMapping("/hello/{msg}")
	ResponseEntity<String> hello(@PathVariable String msg) {
		String result = someService.hello(msg);
		return ResponseEntity.ok(result);
	}
}
