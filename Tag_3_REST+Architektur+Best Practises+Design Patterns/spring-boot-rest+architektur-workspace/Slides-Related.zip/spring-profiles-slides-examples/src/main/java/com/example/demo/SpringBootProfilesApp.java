package com.example.demo;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;


// -Dspring.profiles.active=dev
@SpringBootApplication
@EnableCaching
public class SpringBootProfilesApp {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProfilesApp.class, args);

	}
		
	// Profile-abhängige Runner
	
	@Component
	class MyRunner implements CommandLineRunner {

	    @Autowired
	    private Environment environment;

	    @Override
	    public void run(String... args) throws Exception {

	        System.out.println("Active profiles: " +
	                Arrays.toString(environment.getActiveProfiles()));
	    }
	}

	@Component
	@Profile(value="dev")
	class MyRunner2 implements CommandLineRunner {

	    @Override
	    public void run(String... args) throws Exception {

	        System.out.println("In development");
	    }
	}

	@Component
	@Profile(value="local")
	class MyRunner4 implements CommandLineRunner {

	    @Override
	    public void run(String... args) throws Exception {

	        System.out.println("In local");
	    }
	}

	@Component
	@Profile(value={"dev & local"})
	class MyRunner5 implements CommandLineRunner {

	    @Override
	    public void run(String... args) throws Exception {

	        System.out.println("In development and local");
	    }
	}

	@Component
	@Profile(value={"dev", "prod"})
	class MyRunner6 implements CommandLineRunner {

	    @Value("${app.message}")
	    private String message;

	    @Override
	    public void run(String... args) throws Exception {

	        System.out.println("Message: " + message);
	    }
	}
}
