package aop.employee.service;

import org.springframework.stereotype.Service;

import aop.employee.model.Employee;

@Service
public class EmployeeService {

	public Employee createEmployee(String name, String empId) {

		Employee emp = new Employee();
		emp.setName(name);
		emp.setEmpId(empId);
		return emp;
	}

	public void deleteEmployee(String empId) {

	}

	public Employee getEmployeeById(String empId) {
		Employee emp = new Employee();
		emp.setEmpId(empId);
		return emp;
	}
}
