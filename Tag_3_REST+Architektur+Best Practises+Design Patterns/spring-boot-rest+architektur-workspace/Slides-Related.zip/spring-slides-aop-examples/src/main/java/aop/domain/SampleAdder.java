package aop.domain;

public class SampleAdder {
	public int add(int a, int b) {
		return a + b;
	}
}