package aop.aopdemo;

import org.springframework.stereotype.Component;

@Component
public class Fibonacci
{
   public long calc( int n )
   {
      return ( n < 2 ) ? n : (calc( n - 1 ) + calc( n - 2 ));
   }
}