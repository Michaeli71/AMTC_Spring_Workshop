package aop.aopdemo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import aop.FibonacciAopExampleApp;


@ContextConfiguration(classes = FibonacciAopExampleApp.class)
@SpringBootTest
public class FibonacciTest {
	@Autowired
	private Fibonacci fibonacci;

	@Test
	public void testFibonacci() {
		assertNotNull(fibonacci);
		assertEquals(13, fibonacci.calc(7));
	}
}
