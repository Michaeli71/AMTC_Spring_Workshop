package productapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import productapp.entities.Product;
import productapp.repositories.ProductRepository;

@Service
public class ProductService implements IProductService {

	@Autowired
	ProductRepository repository;

	@Override
	public List<Product> findAll() {
		return repository.findAll();
	}

	@Override
	public Product findById(long id) {
		return repository.findById(id);
	}

	@Override
	public Product create(Product product) {
		return repository.save(product);
	}

	@Override
	public void deleteById(long id) {
		repository.deleteById(id);
	}
}