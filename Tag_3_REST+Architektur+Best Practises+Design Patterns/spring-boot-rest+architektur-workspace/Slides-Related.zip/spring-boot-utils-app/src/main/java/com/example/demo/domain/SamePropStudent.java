package com.example.demo.domain;

public class SamePropStudent {

	String name;
	String university;
	int age;
	int currentSemester;
	
	public SamePropStudent()
	{		
	}
	
	public SamePropStudent(String name, String university, int age, int currentSemester) {

		this.name = name;
		this.university = university;
		this.age = age;
		this.currentSemester = currentSemester;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", university=" + university + ", age=" + age + ", currentSemester="
				+ currentSemester + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getCurrentSemester() {
		return currentSemester;
	}

	public void setCurrentSemester(int currentSemester) {
		this.currentSemester = currentSemester;
	}
	
	
	
}
