package com.example.demo;

import java.lang.reflect.Field;

import org.springframework.beans.BeanUtils;
import org.springframework.util.ReflectionUtils;

import com.example.demo.domain.SamePropStudent;
import com.example.demo.domain.Student;

public class BeanUtilsDemo {

	public static void main(String[] args) {
		
		Student mike = new Student("Mike", "C.v.O", 27, 15);
		Student mikeCopy = new Student();
				
		BeanUtils.copyProperties(mike, mikeCopy);
		System.out.println(mikeCopy);
		
		
		SamePropStudent mikeCopy2 = new SamePropStudent();
		BeanUtils.copyProperties(mike, mikeCopy2, new String[] { "currentSemester" } );
		System.out.println(mikeCopy2);
		
		
		
		Student student = new Student();
//		Field idField = ReflectionUtils.findField(Student.class, "id");
//	    ReflectionUtils.setField(idField, student, 1);
	    
	    Field nameField = ReflectionUtils.findField(Student.class, "name");
	    ReflectionUtils.makeAccessible(nameField);
	    ReflectionUtils.setField(nameField, student, "Peter");
	    
	    System.out.println(student);

	}
}
