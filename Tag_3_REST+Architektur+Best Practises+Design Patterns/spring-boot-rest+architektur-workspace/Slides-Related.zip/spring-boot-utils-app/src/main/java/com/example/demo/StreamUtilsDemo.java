package com.example.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

import org.springframework.util.StreamUtils;

public class StreamUtilsDemo {

	public static void main(String[] args) throws IOException {
		
		// wie transfer() seit JDK 9
		// copy(InputStream in, OutputStream out)
		// copyToByteArray(InputStream in)
		//  	copyToString(InputStream in, Charset charset)
		
		
		String inputFileName = "src/main/resources/input.txt";
	    String outputFileName = "src/main/resources/output.txt";
	    File outputFile = new File(outputFileName);
	    InputStream in = new FileInputStream(inputFileName);
	    OutputStream out = new FileOutputStream(outputFile);
	    
	    StreamUtils.copy(in, out);
	    
	    in = new FileInputStream(inputFileName);
	    String result = StreamUtils.copyToString(in, Charset.defaultCharset());
	    System.out.println(result);
	    
	    in = new FileInputStream(inputFileName);
	    OutputStream outRanged = new FileOutputStream("src/main/resources/output-range.txt");
	    StreamUtils.copyRange(in, outRanged, 1, 10);
	    
	    
	    
	    // FileCopyUtils.copy()
	    // FileSystemUtils.copyRecursively()
	    // StringUtils
	    // ObjectUtils
	}
}
