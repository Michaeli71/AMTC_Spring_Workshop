package productapp.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.stereotype.Repository;

import productapp.entities.Product;

@Repository
public class ProductRepository {

	List<Product> products = new ArrayList<Product>();
	{
		products.add(new Product(100, "Mobile", "CLK98123", 9000.00, 6));
		products.add(new Product(101, "Smart TV", "LGST09167", 60000.00, 3));
		products.add(new Product(103, "Laptop", "LHP29OCP", 24000.00, 1));
		products.add(new Product(104, "Air Conditioner", "ACLG66721", 30000.00, 5));
		products.add(new Product(105, "Refrigerator ", "12WP9087", 10000.00, 4));
	}
	

	public Product save(Product product) {
		products.add(product);
		return product;
	}
	
	public List<Product> findAll() {
		return products;
	}
	
	public Product findById(long id) {
		Predicate<Product> hasDesiredId = product -> product.getId() == id;
		
		return products.stream().filter(hasDesiredId).findFirst().orElseThrow(() -> new IllegalArgumentException("no product for id:" + id));
	}
	
	public void deleteById(long id) {
		Product product = findById(id);
		
		products.remove(product);
	}
}

