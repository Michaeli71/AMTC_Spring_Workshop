package bookapp.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import bookapp.entities.Book;

@Service
public class BookService {

	// TODO: add Repository
	List<Book> bookStore = new ArrayList<>();
	{
		bookStore.addAll(List.of(new Book("Java Challenge", "Michael Inden", LocalDate.of(2020, 8, 26), "1122334")));
	}

	public void deleteById(long id) {
		ensureIdIsValid(id);
	}

	public List<Book> findAll() {
		return bookStore;
	}

	public Book findById(long id) {
		ensureIdIsValid(id);

		return new Book("Python Challenge", "Michael Inden", LocalDate.of(2021, 2, 8), "32332");
	}

	public Book create(Book resource) {
		bookStore.add(resource);
		return resource;
	}

	public void update(long id, Book resource) {
		ensureIdIsValid(id);

		// TODO
	}

	private void ensureIdIsValid(long id) {
		if (id < 0)
			throw new IllegalArgumentException();

	}
}
