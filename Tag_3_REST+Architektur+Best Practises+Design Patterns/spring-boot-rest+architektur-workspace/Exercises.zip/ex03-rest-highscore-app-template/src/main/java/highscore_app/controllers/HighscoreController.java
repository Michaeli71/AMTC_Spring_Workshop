package highscore_app.controllers;

/*
•	POST „Highscore“
•	GET /highscores
•	GET /highscores/top/<n>
•	GET /highscores/byPerson/<name>
•	GET /highscores/byLocalDate/<localdate>
•	DELETE /highscores/<n>
•	DELETE /highscores/of/<name>
•	DELETE /highscores/on/<localdate >
 */
public class HighscoreController {

	// TODO
}
