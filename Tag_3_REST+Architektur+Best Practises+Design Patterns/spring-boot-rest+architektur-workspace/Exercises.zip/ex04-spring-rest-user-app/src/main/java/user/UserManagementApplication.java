package user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//http://localhost:8080/users/create?email=mehl&name=Mic

// =>

// curl -X POST -H "Content-Type: application/json" http://localhost:8080/users/ -d '{ "email" : "mail@mike.de", "name" : "Micha" }'

@SpringBootApplication
public class UserManagementApplication {
	public static void main(String[] args) {
		SpringApplication.run(UserManagementApplication.class, args);
	}
}