package user.repositories;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;

import user.entities.User;

@Transactional
public interface UserDao extends CrudRepository<User, Long> {

	public Optional<User> findByEmail(String email);
}