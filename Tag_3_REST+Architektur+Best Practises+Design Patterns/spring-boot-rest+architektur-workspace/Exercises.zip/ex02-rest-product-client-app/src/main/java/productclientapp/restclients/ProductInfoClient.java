package productclientapp.restclients;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import productclientapp.entities.Product;

@Component
public class ProductInfoClient {

	public static final String SERVER_URI = "http://localhost:8080/products";

	// ACHTUNG: geht nicht!!
	// @Autowired
	private RestTemplate restTemplate;

	@Autowired
	public ProductInfoClient(RestTemplateBuilder builder) {
	    this.restTemplate = builder.build();
	}
		
	@SuppressWarnings("unchecked")
	public List<Product> getAllProducts() {
		List<Product> books = (List<Product>) restTemplate.getForObject(SERVER_URI, List.class);
		System.out.println(books);

		return books;
	}

	public Product getProduct100() {
		Product productWithId100 = restTemplate.getForObject(SERVER_URI + "/100", Product.class);
		System.out.println(productWithId100);

		return productWithId100;
	}
	
	public void createProduct(Product book) {
		Product response = restTemplate.postForObject(SERVER_URI, book, Product.class);
		System.out.println(response);
	}
}