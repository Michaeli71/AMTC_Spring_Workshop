package productclientapp;

import java.util.List;

import org.springframework.web.client.RestTemplate;

import productclientapp.entities.Product;

public class StandaloneRestClientExample {

	public static final String SERVER_URI = "http://localhost:8080/products";

	public static void main(String args[]) {

		RestTemplate restTemplate = new RestTemplate();

		getAllProducts(restTemplate);
		System.out.println("*****");
		getProduct100(restTemplate);
		System.out.println("*****");
		Product product = new Product(4711, "IPAD", "PRO", 10101, 12345);
		createProduct(restTemplate, product);
		System.out.println("*****");
		getAllProducts(restTemplate);
		System.out.println("*****");
		
		// check validation
//		Product illegal_product = new Product(-4711, "IPAD", "PRO", 10101, 12345);
//		createProduct(restTemplate, illegal_product);
		
		System.out.println(getProductById(restTemplate, 100));
		System.out.println(getProductById(restTemplate, -4711));
	}

	public static void createProduct(RestTemplate restTemplate, Product product) {
		Product response = restTemplate.postForObject(SERVER_URI, product, Product.class);
		System.out.println(response);
	}
	
	@SuppressWarnings("unchecked")
	public static List<Product> getAllProducts(RestTemplate restTemplate) {
		List<Product> books = (List<Product>) restTemplate.getForObject(SERVER_URI, List.class);
		System.out.println(books);

		return books;
	}

	public static Product getProduct100(RestTemplate restTemplate) {
		Product productWithId100 = restTemplate.getForObject(SERVER_URI + "/100", Product.class);
		System.out.println(productWithId100);

		return productWithId100;
	}
	
	public static Product getProductById(RestTemplate restTemplate, long id) {
		Product productWithId = restTemplate.getForObject(SERVER_URI + "/" + id, Product.class);
		System.out.println(productWithId);

		return productWithId;
	}
	
}