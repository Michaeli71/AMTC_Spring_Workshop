package user.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import user.entities.User;
import user.repositories.UserDao;

/*
    /create?email=[email]&name=[name]: create a new user with an auto-generated id and email and name as passed values.
    /delete?id=[id]: delete the user with the passed id.
    /get-by-email?email=[email]: retrieve the id for the user with the given email address.
    /update?id=[id]&email=[email]&name=[name]: update the email and the name for the user identified by the given id.
 */
@RestController
@RequestMapping("users")
public class UserController {

	@RequestMapping("")
	public Iterable<User> getAll() {

		return userDao.findAll();
	}

	/**
	 * GET /create --> Create a new user and save it in the database.
	 */
	@RequestMapping("/create")
	public String create(String email, String name) {
		String userId = "";
		try {
			User user = new User(email, name);
			userDao.save(user);
			userId = String.valueOf(user.getId());
		} catch (Exception ex) {
			return "Error creating the user: " + ex.toString();
		}
		return "User succesfully created with id = " + userId;
	}

	/**
	 * GET /delete --> Delete the user having the passed id.
	 */
	@RequestMapping("/delete")
	public String delete(long id) {
		try {
			User user = new User(id);
			userDao.delete(user);
		} catch (Exception ex) {
			return "Error deleting the user:" + ex.toString();
		}
		return "User succesfully deleted!";
	}

	/**
	 * GET /get-by-email --> Return the id for the user having the passed email.
	 */
	@RequestMapping("/get-by-email")
	public String getByEmail(String email) {
		String userId = "";
		try {
			User user = userDao.findByEmail(email);
			userId = String.valueOf(user.getId());
		} catch (Exception ex) {
			return "User not found";
		}
		return "The user id is: " + userId;
	}

	/**
	 * GET /update --> Update the email and the name for the user in the database
	 * having the passed id.
	 */
	@RequestMapping("/update")
	public String updateUser(long id, String email, String name) {

		Optional<User> optUser = userDao.findById(id);
		if (optUser.isPresent())
		{
			User user = optUser.get();
			user.setEmail(email);
			user.setName(name);
			userDao.save(user);
			return "User succesfully updated!";
		}
		
		return "Error updating the user: Not found for id " + id;
	}


	@Autowired
	private UserDao userDao;
}