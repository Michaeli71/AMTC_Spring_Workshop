package highscore_app.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import highscore_app.entities.Highscore;
import highscore_app.repositories.HighscoreRepository;


// Noch deutlich kompleer in der realität, da die Highscore alle nach Datum, Punkt und Level
// geordent sein müssen! => Hier über Repository versteckt

@Service
public class HighscoreService {

	@Autowired
	private HighscoreRepository repository;
	
	public List<Highscore> getAll() {
	
		return repository.findByOrderByPointsDescDayDescLevelDesc();
	}

	public Highscore createHighscore(String name, int points, int level) {

		Highscore highscore = new Highscore(name, points, level, LocalDate.now());
		repository.save(highscore);

		return highscore;
	}
	
	public List<Highscore> getByPerson(String name) {
		List<Highscore> usersHighscores = repository.findByName(name);
		if (usersHighscores.isEmpty()) {

			throw new HighscoreNotFoundException("no highscores found for name " + name);
		}
		
		return usersHighscores;
	}

	public void deleteByPos(int pos) {
		
		List<Highscore> highscores = getAll(); 
		if (highscores.size() < pos)
			throw new HighscoreNotFoundException("no highscores found for pos " + pos);
		
		Highscore highscore = highscores.get(pos);
		repository.deleteById(highscore.getId());
	}

	public List<Highscore> getTop5() {
		return repository.findTop5ByOrderByPointsDescDayDescLevelDesc();
		
		//List<Highscore> highscores = getAll();
		//return highscores.subList(0, Math.min(5, highscores.size()));
	}
	

	public List<Highscore> getTopN(int n) {
		List<Highscore> highscores = getAll();
		return highscores.subList(0, Math.min(n, highscores.size()));
	}
}
