package productclientapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import productclientapp.entities.Product;
import productclientapp.restclients.ProductInfoClient;

@SpringBootApplication
public class ProductInfoClientAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductInfoClientAppApplication.class, args);
	}
	
	@Component
	public class MyCommandLineRunner implements CommandLineRunner {

		@Override
		public void run(String... args) throws Exception {
			// TODO
		}
	}
}
