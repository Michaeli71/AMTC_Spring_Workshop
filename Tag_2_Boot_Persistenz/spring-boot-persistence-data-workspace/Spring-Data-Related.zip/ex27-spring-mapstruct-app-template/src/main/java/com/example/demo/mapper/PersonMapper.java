package com.example.demo.mapper;

// TODO
public interface PersonMapper {
	// TODO
}