package app.controller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import app.controller.repositories.PersonRepository;
import app.model.Person;

@Service
public class PersonService {

	//final PersonDAO personDao;
	private PersonRepository personRepository;	
	
	@Autowired
	public PersonService(PersonRepository personRepository) {
		this.personRepository = personRepository;
	}

	public Iterable<Person> getAll() {
		return personRepository.findAll();
	}

	public Person createNewPerson(Person person) {
		personRepository.save(person);
		return person;
	}

	public List<Person> getByNationality(String nationality) {
		return personRepository.findByNationality(nationality);
	}

	public List<Person> getOlderThan(Integer age) {
		return personRepository.findByAgeGreaterThan(age);
	}

	public void deleteById(long id) {
		personRepository.deleteById(id);		
	}
}
