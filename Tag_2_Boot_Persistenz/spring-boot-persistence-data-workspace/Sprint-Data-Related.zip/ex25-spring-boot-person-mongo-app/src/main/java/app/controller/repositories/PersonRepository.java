package app.controller.repositories;

import java.util.Collection;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import app.model.Person;

@Repository
public interface PersonRepository extends MongoRepository<Person, String> {
	List<Person> findByNationality(String nationality);

	List<Person> findByAgeGreaterThan(Integer age);

	List<Person> findByAgeBetween(int lower, int upper);

	int countByAgeBetween(int lower, int upper);

	List<Person> findTop3ByAgeLessThan(int maxAge);

	List<Person> findByAgeLessThanOrderByNameAsc(int maxAge);

	List<Person> getByNameLike(String name);

	List<Person> findByNameOrNationality(String name, String lastName);

	List<Person> findByNameInAndAgeBetween(Collection<String> names, int lower, int upper);
}
