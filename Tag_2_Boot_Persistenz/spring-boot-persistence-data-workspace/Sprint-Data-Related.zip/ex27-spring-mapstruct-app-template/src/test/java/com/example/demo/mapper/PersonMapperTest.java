package com.example.demo.mapper;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.example.demo.domain.PersonDto;
import com.example.demo.entities.Person;


public class PersonMapperTest {
	
    // TODO
	private PersonMapper mapper = null;

	@Test
	public void mapToEntity() {
	    PersonDto personDto = new PersonDto();
	    personDto.setId(4711);
	    personDto.setName("Michael Inden");
	    personDto.setBirthday(LocalDate.of(1971, 2, 7));
	
	    // TODO
	}
	
	@Test
	public void mapToDto() {
		Person person = new Person();
	    person.setId(4711);
	    person.setName("Michael Inden");
	    person.setBirthday(LocalDate.of(1971, 2, 7));
	
	    // TODO
	}
	
	
	@Test
	public void mapToNameDto() {
		Person person = new Person();
	    person.setId(4711);
	    person.setName("Michael Inden");
	
	    // TODO

	}
}

