package mongo;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class FirstMongoAccessExample {

	public static void main(String[] args) {

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("codingsession");

		MongoCollection<Document> collection = database.getCollection("databases");

		Document doc = new Document("name", "MongoDB").
				append("type", "database").
				append("count", 1).
				append("info", new Document("x", 203).append("y", 102));
		collection.insertOne(doc);
		
		System.out.println("Inspecting persons");
		MongoCollection<Document> persons = database.getCollection("persons");

		FindIterable<Document> findIterable = persons.find();
		MongoCursor<Document> cursor = findIterable.iterator();
		while (cursor.hasNext()) {

			final Document dbObj = cursor.next();
			System.out.println(dbObj);
		}

		// close resources
		mongoClient.close();
	}
}
