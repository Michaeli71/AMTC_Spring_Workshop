package mongo;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class SecondMongoAccessExample {

	public static void main(String[] args) {

		MongoClient mongoClient = new MongoClient("localhost", 27017);

		// Aufgabe 1
		MongoDatabase database = mongoClient.getDatabase("codingsession");
		MongoCollection<Document> persons = database.getCollection("persons");

		// Aufgabe 2
		exercise2(persons);
		
		// Aufgabe 3
		MongoCollection<Document> employees = exercise3(database);

		// Aufgabe 4
		System.out.println("DB-Names");
		final List<String> dbNames = new ArrayList<>();
		mongoClient.listDatabaseNames().into(dbNames);
		System.out.println(dbNames);
		
		// Aufgabe 5
		System.out.println("Collection-Names");
		final List<String> collectionNames = new ArrayList<>();
		database.listCollectionNames().into(collectionNames);
		System.out.println(collectionNames);
		
		// Aufgabe 6
		printAllFromCollection(persons);
		printAllFromCollection(employees);

		System.out.println("Persons junger than 30");
		String jungerThen30 = "{\"age\": {$lt : 30} }";
		Document filterAsDoc = Document.parse(jungerThen30);
		FindIterable<Document> findIterable = persons.find(filterAsDoc);
		printElements(findIterable);
		
		System.out.println("Employes Older than 40");
		String olderThan40 = "{\"age\": {$gt : 40} }";
		Document filterAsDoc2 = Document.parse(olderThan40);
		FindIterable<Document> findIterable2 = employees.find(filterAsDoc2);
		printElements(findIterable2);

		// Rest analog zu den Filtern oben
		
		
		// close resources
		mongoClient.close();
	}

	protected static void printAllFromCollection(MongoCollection<Document> collection) {
		System.out.println("Inspecting " + collection.getNamespace());

		FindIterable<Document> findIterable = collection.find();
		printElements(findIterable);
	}

	protected static void printElements(FindIterable<Document> findIterable) {
		MongoCursor<Document> cursor = findIterable.iterator();
		while (cursor.hasNext()) {

			final Document dbObj = cursor.next();
			System.out.println(dbObj);
		}
	}

	protected static void exercise2(MongoCollection<Document> persons) {
		Document doc = new Document("name", "Beat").
				append("nationality", "swiss").
				append("age", 35).
				append("info", new Document("x", 203).append("y", 102));
		persons.insertOne(doc);
		
		String peterAsJson = "{ \"name\" : \"Peter\", \"nationality\" : \"german\", \"age\" : 29 }";
		Document perterAsDoc = Document.parse(peterAsJson);
		persons.insertOne(perterAsDoc);
		
		String timAsJson = "{ \"name\" : \"Tim\", \"address\" : { \"city\" : \"Kiel\", \"PLZ\": 24106 } }";
		Document timAsDoc = Document.parse(timAsJson);
		persons.insertOne(timAsDoc);
	}
	
	protected static MongoCollection<Document> exercise3(MongoDatabase database) {
		
		MongoCollection<Document> employees = database.getCollection("employees");
		
		String carloAsJson = "{ \"surname\" : \"Carlo\", \"name\" : \"Giorgetta\", \"company\" : \"Swisscom\", \"age\" : 42 }";
		Document carloAsDoc = Document.parse(carloAsJson);
		employees.insertOne(carloAsDoc);
		
		String hermannAsJson = "{ \"surname\" : \"Hermann\", \"name\" : \"Schnyder\", \"company\" : \"Swisscom\", \"age\" : 42 }";
		Document hermannAsDoc = Document.parse(hermannAsJson);
		employees.insertOne(hermannAsDoc);
		
		return employees;	
	}
}
