package mongo;

import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;


public class MongoCrudExample {

	public static void main(String[] args) {

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("crud_example");

		MongoCollection<Document> collection = database.getCollection("employees");

		String jsonString = "{ \"surname\" : \"Hendrik\" , \"name\" : \"Schöneberg\" , "
				+ " 'role' : 'Senior Software Engineer' , 'age' : 33}";

		Document doc = Document.parse(jsonString);
		ObjectId idBefore = doc.getObjectId("_id");
		collection.insertOne(doc);	
		ObjectId idAfter = doc.getObjectId("_id");
		System.out.println("idBefore " + idBefore);
		System.out.println("idAfter " + idAfter);
		
		readAndPrintAll(database);
		collection.insertOne(Document.parse(jsonString));
		
		// Update
		String byName = "{ \"surname\" : \"Hendrik\"}";
		String setJson = "{$set: {\"name\" : \"C H A N G E D  A L L\"}}";
		collection.updateMany(Document.parse(byName), Document.parse(setJson));

		String byId = "{ \" : " + idAfter + "}";
		String setJson2 = "{$set: {\"name\" : \"BY ID\"}}";
		Document changed = collection.findOneAndUpdate(eq("_id", idAfter), Document.parse(setJson2));
		System.out.println("changed " + changed);

		readAndPrintAll(database);
		
		Document byId2 = new Document();
		byId2.append("_id", idAfter);
		String setJson3 = "{$set: {\"name\" : \"BY ID --- 2 \"}}";
		Document changed2 = collection.findOneAndUpdate(byId2, Document.parse(setJson3));
		System.out.println("changed2 " + changed2);
		
		readAndPrintAll(database);
				
		// Delete
		collection.deleteOne(byId2);
		readAndPrintAll(database);
		
		// close resources
		mongoClient.close();
	}

	protected static void readAndPrintAll(MongoDatabase database) {
		System.out.println("Inspecting employees");
		MongoCollection<Document> persons = database.getCollection("employees");

		FindIterable<Document> findIterable = persons.find();
		MongoCursor<Document> cursor = findIterable.iterator();
		while (cursor.hasNext()) {

			final Document dbObj = cursor.next();
			System.out.println(dbObj);
		}
	}
}
