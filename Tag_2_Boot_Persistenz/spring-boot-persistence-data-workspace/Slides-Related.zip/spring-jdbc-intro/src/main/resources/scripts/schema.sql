create table EMPLOYEE (
    id integer not null primary key,
    name varchar(20) not null,
    salary float not null
);