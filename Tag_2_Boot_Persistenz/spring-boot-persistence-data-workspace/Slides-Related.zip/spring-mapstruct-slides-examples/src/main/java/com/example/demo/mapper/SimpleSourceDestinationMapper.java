package com.example.demo.mapper;

import org.mapstruct.Mapper;

import com.example.demo.domain.SimpleDestination;
import com.example.demo.domain.SimpleSource;

@Mapper
public interface SimpleSourceDestinationMapper {
	SimpleDestination sourceToDestination(SimpleSource source);

	SimpleSource destinationToSource(SimpleDestination destination);
}