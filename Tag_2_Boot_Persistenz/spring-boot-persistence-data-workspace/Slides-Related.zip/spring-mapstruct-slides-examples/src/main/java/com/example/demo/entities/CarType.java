package com.example.demo.entities;

public enum CarType {
	PLAIN, PICKUP, SUV, TRUCK
}
