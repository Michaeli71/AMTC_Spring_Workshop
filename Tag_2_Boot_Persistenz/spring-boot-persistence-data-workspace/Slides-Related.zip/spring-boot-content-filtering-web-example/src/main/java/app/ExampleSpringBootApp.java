package app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ExampleSpringBootApp {

	public static void main(String[] args) {
		SpringApplication.run(ExampleSpringBootApp.class, args);
	}
}
