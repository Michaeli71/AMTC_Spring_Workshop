package validation.custom;

import javax.validation.constraints.NotBlank;

public class ValidatedDomainClass 
{
	@NotBlank(message = "Deposit Date is required.")
	@CheckLocalDate(dateFormat = { "yyyy-MM-dd" })
	String depositDate;

	@CheckLocalDate(dateFormat = "dd.MM.yyyy")
	String publicationDate;

	@CheckLocalDate(dateFormat = { "dd.MM.yyyy", "dd.MM.yy" })
	String collectionDate;
	
	// Enum-Validator für Legacy
	@CheckEnum(type = Seasons.class)
	String season;
	
	@CheckEnum(type = SpecialColors.class)
	String color;
	
	@CheckListOfValues(allowedValues = { "Anne", "Will", "Peter", "Lustig"})
	String value;
}
