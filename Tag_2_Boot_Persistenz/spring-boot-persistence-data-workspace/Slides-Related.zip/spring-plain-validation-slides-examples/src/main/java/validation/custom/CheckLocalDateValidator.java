package validation.custom;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CheckLocalDateValidator implements ConstraintValidator<CheckLocalDate, String> {
	String[] dateFormat = { "" };

	@Override
	public void initialize(CheckLocalDate constraintAnnotation) {
		dateFormat = constraintAnnotation.dateFormat();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		return validate(value);
	}

	private boolean validate(String dateString) {
		boolean valid = false;
		if (dateString.isEmpty()) {
			return true;
		}
		
		for (String format : dateFormat) {
			valid = isValidDate(dateString, format);
			if (valid)
				break;
		}
		return valid;
	}

	private boolean isValidDate(String dateString, String pattern) {
		try {
			final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
			// System.out.println("Trying for " + dateString + " with " + pattern);
			LocalDate date = LocalDate.parse(dateString.trim(), formatter);
			// System.out.println(("Parsed " + date));
			return true;
		} catch (DateTimeParseException e) {
			//System.out.println("Failed for " + dateString + " with " + pattern);
			return false;
		}
	}
}
