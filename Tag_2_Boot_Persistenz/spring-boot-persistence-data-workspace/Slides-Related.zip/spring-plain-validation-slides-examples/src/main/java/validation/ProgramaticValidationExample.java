package validation;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

public class ProgramaticValidationExample 
{
	public static void main(final String[] args) 
	{
		UserWithValidation user = new UserWithValidation();
		user.setWorking(false);
		user.setAboutMe("No info about me!");
		user.setAge(11);

		try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory())
		{
			Validator validator = factory.getValidator();
			
			Set<ConstraintViolation<UserWithValidation>> violations = validator.validate(user);
			for (ConstraintViolation<UserWithValidation> violation : violations) 
			{
				System.err.println(violation.getMessage());
			}
		}		
	}
}
