package springjdbc.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import springjdbc.dao.PersonDAO;
import springjdbc.domain.Person;

@RestController
public class PersonController {

	@Autowired
	PersonDAO personDao;

	/*
	@GetMapping("/persons")
	public List<Person> getAllPersons() {
		return personDao.getAllPersons();
	}
*/
	@GetMapping(value="/persons", produces= { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public List<Person> getAllPersons(){
		return personDao.getAllPersons();
	}

	
	@GetMapping("/persons/{personId}")
	public Person getPersonById(@PathVariable("personId") long id) {
		return personDao.getPersonById(id);
	}
	
	@GetMapping("/person") // => person?personId=4 
	public Person getPersonById2(@RequestParam("personId") long id) {
		return personDao.getPersonById(id);
	}
}
