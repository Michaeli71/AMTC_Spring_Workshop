package ch.asmiq;

import ch.asmiq.tomcat.TomcatStarter;


public class AsmiqAcademyApp {

	public static void main(final String[] args) throws InterruptedException {
		
		TomcatStarter.startTomcat();
	}
}