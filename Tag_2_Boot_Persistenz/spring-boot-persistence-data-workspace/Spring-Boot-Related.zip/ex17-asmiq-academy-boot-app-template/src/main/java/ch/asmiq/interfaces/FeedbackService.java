package ch.asmiq.interfaces;

import ch.asmiq.model.Order;

public interface FeedbackService {

	void conductSurvey(Order order);
}
